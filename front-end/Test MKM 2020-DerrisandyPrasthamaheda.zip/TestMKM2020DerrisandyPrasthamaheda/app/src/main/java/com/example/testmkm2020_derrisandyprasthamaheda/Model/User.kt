package com.example.testmkm2020_derrisandyprasthamaheda.Model

class User(var id: Int,var username: String?, var logintime: String?, var loginstate: String?)